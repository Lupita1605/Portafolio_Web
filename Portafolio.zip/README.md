  <p align="center">
    <img src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" alt="HTML5" />
    <img src="https://img.shields.io/badge/AZURE_APP_SERVICE-0078D4?style=for-the-badge&logo=microsoftazure&logoColor=white" alt="Azure" />
  </p>

  <p align="center">
    <b>• Diseño Web • Despliegue en la Nube</b>
  </p>

  ---

  # 🌐 Mi Portafolio Web

  Este repositorio aloja mi portafolio web interactivo desarrollado para la materia de **Programación Web**, el cual recopila prácticas, proyectos y temas de estudio. El sitio se encuentra actualmente alojado y desplegado en la nube a través de **Microsoft Azure App Service** sobre un entorno Linux.

  🔗 **Sitio en vivo:** [Ver Portafolio en Azure](https://programacionweb-b4bvf7cdh6hjezam.eastus2-01.azurewebsites.net/)
